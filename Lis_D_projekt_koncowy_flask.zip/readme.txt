Aplikacja służy do przechowywania notatek
-----------------------------------------


baza danych zawiera 3 tabele:
1.Users
2.Grupy
3.Notatki

utworzone są 2 konta:
1.login: user1 haslo: 12345678
2.login: user2 haslo: 87654321


skrótowy opis aplikacji:
-po utworzeniu konta user może zmienić nickname lub usunąć konto
-każdy user tworzy sobie grupy w których może umieścić notatki
-nazwy grup można edytować
-notatki dodajemy zawsze do jakiejś grupy
-nazwy notatek i ich treść można edytować
-wraz z usunięciem grupy usuwane są też znajdujące się w niej notatki
-wraz z usunięciem konta usuwane są wszystkie grupy usera i notatki
